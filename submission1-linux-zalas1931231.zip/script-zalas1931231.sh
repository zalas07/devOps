#! /bin/bash



while true

memorysize=$(df -h /dev/sda2 | grep /dev/sda | awk '{print $2}')
usedisk=$(df -hBG /dev/sda2 | grep /dev/sda | awk '{print $3}' )
usedns=$(df -h /dev/sda2 | grep  /dev/sda |  awk '{print $1, $5}')

do

echo 'menampilkan ukuran memory dalam filesystem menggunakan satuan megabyte'
echo $memorysize
sleep 3

echo 'menampilkan penggunan ruang disk untuk kolom  pada filesystem dalam satuan gigabyte'
echo $usedisk

sleep 3
echo 'menampilkan penggunaan ruang disk pada filesystem untuk kolom filesystem dan kolom use'
echo $usedns

sleep 60

done
